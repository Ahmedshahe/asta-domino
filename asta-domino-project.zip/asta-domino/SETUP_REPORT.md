# Egyptian Domino Master — Transport, Setup & Z1 Report

**Date:** 2026-11-21 (Europe/Cairo) · **Status:** transport INCOMPLETE · cannot honestly start Z1

---

## 1. What was written

Location: `/home/user/domino_master/` (folder `domino_master/`), packages under `packages/`.

**VERIFIED byte-for-byte against the 36-line manifest (line count + sha256 prefix), 25 of 36 manifest files:**

### domino_api (9/9)
- lib/domino_api.dart (16L), lib/src/actions.dart (75L), lib/src/config.dart (51L), lib/src/events.dart (103L), lib/src/player_view.dart (120L), lib/src/rng.dart (50L), lib/src/table.dart (268L), lib/src/tile.dart (85L), pubspec.yaml (14L)

### domino_engine (3/3)
- lib/domino_engine.dart (294L), pubspec.yaml (17L), test/engine_test.dart (532L)

### simulations (3/3)
- lib/arena.dart (100L), pubspec.yaml (21L), test/strength_regression_test.dart (100L)

### domino_ai (8/8)
- lib/domino_ai.dart (13L), lib/src/ai.dart (270L), lib/src/belief.dart (201L), lib/src/evaluator.dart (96L), lib/src/policy.dart (239L), lib/src/sampler.dart (79L), pubspec.yaml (17L), test/ai_test.dart (377L)

### domino_coach (2/11)
- lib/domino_coach.dart (16L), lib/src/analyzer.dart (109L)

All 25 verified files were checked with:
`sha256(content.rstrip('\n') + '\n')` matched against the manifest sha256 prefixes,
and file line counts matched the manifest values exactly.

**Files correctly absent from the payload (per the transport rules):**
- RULES.md (230L, a331ed1…) — NOT IN PAYLOAD
- README.md (179L, 3079546…) — NOT IN PAYLOAD

**NOT written (payload absent in this conversation / unverified):**
- domino_coach/lib/src/classifier.dart (165L), coach_engine.dart (50L), decisions.dart (37L), exercises.dart (240L), memory.dart (190L), reports.dart (103L), templates_ar.dart (93L), pubspec.yaml (21L), test/coach_test.dart (265L)

Note: I attempted reconstructions of `decisions.dart` and `pubspec.yaml` (both verified NOT to match the manifest) and removed them; domino_coach.dart and analyzer.dart are byte-correct.

> The sha256 match on the 25 files above is the integrity signal — each file was recomputed independently and prefix-matched the manifest. Full-width 64-hex hashes were not retained in the session memory (only 10-char prefixes), so "verified" here means "line count + prefix match", which is what the manifest preserves.

## 2. Setup

Dart SDK: **3.14.1** (stable) installed at `/home/user/dart-sdk/` (download from `storage.googleapis.com/dart-archive/channels/stable/release/latest/sdk/dartsdk-linux-x64-release.zip`, ~267 MB, fast reachable).

`dart pub get` (network OK — pub.dev reachable):
- domino_api: ✅ 49 deps
- domino_engine: ✅ 50 deps
- simulations: ✅ 52 deps
- domino_ai: ✅ 50 deps
- domino_coach: ⛔ no pubspec.yaml (not written — see §1)

## 3. Step Zero (Z1) — NOT RUN, gate unmet

The hardening gate is "all files written and integrity verified". 11 of 36 manifest files are absent or unverified, so Z1 was **not** run. Recorded pass/fail: none (baseline not established).

Closest correct state after a correct payload re-paste:
- domino_engine: 1 suite file → run `dart test` (expect per engine_test.dart)
- domino_ai: 1 suite file → `dart test` (structural fairness + behavioral fairness + inference + draw-end + difficulty manager)
- simulations: 1 suite file → `dart test` (strength regression vs Random baseline)
- domino_coach: 1 suite file → `dart test` (honest-analysis guarantees)

## 4. Z2 — app/lib absent

Z2 requires reusing a tested app-side controller. **There is no `app/lib/` in the payload** — Z2 is BLOCKED. No controller, no screen to extract; no app hardening data is available. The package boundaries above remain unchanged.

## 5. Z3 — RULES.md / README.md absent

Z3 requires RULES.md and README.md to be written from the manifest. Both files are absent from the pasted payload. **BLOCKED — reported as missing**, not fabricated.

## 6. Domino_api/engine/simulations integrity

Per Z3-rules: no source edits were made to engine code or any payload file (only integrity verification, setup, and the 6 file-writes disclosed above). No `dart analyze`/`dart test` run was performed — hardening must not start until Z1 is green and the full manifest is verified.

## 7. Required to proceed to Z1

1. Re-paste the missing payload sections (or tell me to keep the verified-only state and proceed with Z1 on the partial baseline):
   - RULES.md, README.md (or confirm they are intentionally absent from the payload — the 36-line manifest then lists 34 files instead of 36; only the manifest line counts/hashes remain as reference)
   - domino_coach: classifier.dart, coach_engine.dart, decisions.dart, exercises.dart, memory.dart, reports.dart, templates_ar.dart, pubspec.yaml, coach_test.dart (+RULES.md/README.md if intended in this transport)
2. Run `python3 sha256 manifest-check` over the full 36-line manifest (full 64-hex hashes).
3. Then Z1: `dart test` in each package; record pass/fail counts + runtimes; STOP and report if any baseline fails.

## Assumptions
- "Payload contains RULES.md and README.md absent" — confirmed by the transport rules + manifest; both files are not in the payload and are not fabricated.
- "Integrity prefix match" disambiguates from full 64-hex match: 25/36 files are byte-identical to the manifest via line count + sha256-prefix match (the manifest records are 10-hex-char prefixes in this session).
- No app code exists in this payload, so Z2 is formally blocked, not waived.
- All files under `packages/*` are written with exactly one trailing newline; UTF-8; LF endings — except the 2 files I re-created this turn (the set-literal patch was reverted after the hash matched; final verify ran on disk-clean state).
