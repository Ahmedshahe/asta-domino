# ARCHITECTURE REVIEW — Asta Domino

## Package boundaries — enforcement

| Boundary | Status | Evidence |
|---|---|---|
| domino_api: no MatchState / no GameState / no hidden info | ✅ enforced | lib/domino_api.dart exports only actions/config/events/player_view/rng/table/tile; `PlayerView` is the resource encoding hidden info boundaries; ai_test verifies. |
| domino_engine: MatchState-only (engine-only type) | ✅ | MatchState lives in domino_engine; PlayerView is constructed by `playerView()`; `player_view.dart` is the only input contract. |
| domino_ai: no engine access | ✅ | ai_test scans pubspec (no domino_engine) + grep for `dart:io`/`MatchState`/`domino_engine` in `lib/` — all clean. Structural dependency graph only uses api. |
| domino_coach: must respect PlayerView boundary | ⚠️ unverifiable | pubspec missing; source imports api + ai (confirmed by `analyzer.dart`); no dependency on engine (confirmed), but no tests exist to prove behavior. |
| simulations: bridge for benchmark only | ✅ | Depends on api + engine + ai; used by strength regression; never imported by engine/ai. |
| app: UI-side boundary (Z2) | ❌ absent | app/ not in payload — Z2 blocked. |

## API surfaces

All public types have **value equality** appropriate for a rules engine (Tile, PlacedTile, DominoAction, RoundResult, PlayerView). Actions are sealed (`sealed class DominoAction`) enabling exhaustive switch — verified by `applyTableAction`'s switch.
`GameEvent` is also sealed with `forViewer()` redaction — yt-agnostic to which viewer is acted.
No runtime dependency on the `test` package in runtime source (confirmed by analyzing imports).

## Strength of the architecture

- **Privacy by construction** — the viewer is physically disallowed from seeing the engine's `MatchState`; all AI and coach code is self-contained within domino_api-defined contracts.
- **Deterministic** — `Rng(xorshift32)` with explicit `Rng.fromState` for re-seeding; engine relies on the same path for the deal.

## Weaknesses and recommendations

1. **E1 — `stopwatch` nondeterminism in Master AI** (see BUG-02). Keep wall-clock OUT of the determinization loop of the AI. Recommended: record the number of worlds used as part of the public state, or make time budget a non-breaking "soft cap that must not change decision space". This is not a behavior change; it is an invariant guarantee.
2. **E2 — Mutable globals** `activeWinBonus` / `activeRolloutWeights` in evaluator.dart / policy.dart. Replace with per-call parameters (or at least freeze them in const or keep them private to analysis-only tooling). Otherwise any code path can silently tune the AI.
3. **E3 — domino_api lacks tests.** It is the most-loaded package and the foundation. Its invariants (tile validation, equality, config) deserve a `test/` directory.
4. **E4 — domino_coach boundary cannot be verified.** Until `decisions.dart` etc. are restored, `domino_coach.dart` can't analyze, so the coach privacy guarantee cannot be validated. Same as BUG-01.
5. **E5 — `buildBelief` slot-model approximation is heuristic.** Reasonable for AI inference — not a privacy violation but must not be presented as "the opponent's exact hand". Documentation/comment should say exactly that.
6. **E6 — Draw direction semantics** — `chosen direction stays fixed` — implemented per `applyTableAction` + regression test; no change requested.
7. **E7 — Naming**: actions use `DrawSide.front`/back abstraction cleanly; `chain.left/right` consistent. No renaming requested.

## What was NOT done
- Not rewrote any source files — AUDIT ONLY, plus additions of reports.
- Not modified: domino_api / domino_engine / domino_ai / simulations source.

**Status:** PASS WITH DOCUMENTED LIMITATIONS
