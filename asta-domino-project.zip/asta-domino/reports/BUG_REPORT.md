# BUG REPORT — Asta Domino

**Method:** Manual inspection + static analysis + test execution + ad-hoc runtime checks.
**Strict rule applied:** no issue is reported as "confirmed" unless the evidence is directly observable in this environment (a file, a command output, or a test).

## Confirmed defects/gaps

### BUG-01 — domino_coach package is incomplete (missing 9 source files + no tests)
**Severity:** High (architectural completeness; package fails to compile)
**Affected Package:** domino_coach
**Affected Files:** `packages/domino_coach/lib/domino_coach.dart` (exports missing files), `packages/domino_coach/lib/src/analyzer.dart` (imports missing `decisions.dart`)
**Problem:** The manifest lists 11 files for this package (16L lib/domino_coach.dart, 109L lib/src/analyzer.dart, 165L classifier.dart, 50L coach_engine.dart, 37L decisions.dart, 240L exercises.dart, 190L memory.dart, 103L reports.dart, 93L templates_ar.dart, 21L pubspec.yaml, 265L test/coach_test.dart). Only 2 of 11 are present. `lib/domino_coach.dart` exports 9 files that do not exist in the workspace; `analyzer.dart` imports `decisions.dart`. The package therefore cannot build — this is not a code defect but a **transport/completeness defect**.
**Reproduction:** `cd packages/domino_coach && cat ../domino_coach/lib/domino_coach.dart | grep export` → 9 exports with no matching source file; `ls packages/domino_coach` → 2 files only.
**Expected:** All 11 files present and package fully analyzes/compiles.
**Actual:** 2/11 present; `dart analyze` cannot run (no pubspec.yaml).
**Root Cause:** The payload arrived incomplete (RULES.md/README.md absent by design; the 9 coach files are genuinely missing).
**Fix:** Re-paste the missing 9 files from the payload. Do NOT substitute a reconstruction — per the transport rule «do not fabricate replacements».
**Regression test:** `dart analyze packages/domino_coach` must report clean; `dart test packages/domino_coach` must pass.
**Risk of fix:** none — files are additive.
**Verification:** not run (blocked).

### BUG-02 — domino_ai test has a timing-dependent determinism assumption
**Severity:** Medium (structural; no test failure observed today)
**Affected Package:** domino_ai
**Affected File:** `packages/domino_ai/lib/src/ai.dart:207-219` (`_master` uses `Stopwatch` + `masterTimeBudgetMs`), `packages/domino_ai/test/ai_test.dart:71-91`
**Problem:** `DominoAI._master` stops the determinization loop once `Stopwatch().elapsedMilliseconds > masterTimeBudgetMs` — a wall-clock condition. The structural/behavioral determinism tests compare two freshly seeded AI instances head-to-head; if the budget fires in one instance but not the other (machine load variance, slow CI), the two instances evaluate different numbers of worlds and may return different actions. This weakens the "same view (+seed) => same decision" guarantee (RULES §Fairness). The package itself does not depend on wall-clock elsewhere — only this one function measures time.
**Reproduction:** Static inspection; cannot force fire on the current machine, but documented by the `Stopwatch()` call in the source. On a throttled/slow machine the two master instances can diverge (the regression suite uses 150 worlds, which the comment in test acknowledges could exceed a budget on slow hardware).
**Expected:** Decision is a function of the view (+seed) only.
**Actual:** Decision may vary under time pressure.
**Root Cause:** Master uses wall-clock as a termination condition instead of a fixed world count.
**Fix (recommended, NOT applied):** Make the budget non-breaking — e.g. always evaluate exactly `masterDeterminizations` worlds and use wall-clock only to report time eaten; or, if a time budget is required, make it a *two-phase* protocol where the budget cannot change the *number* of worlds evaluated (sample 150 but record which were used; if budget fires, continue to compare the SAME worlds across all candidates). Do not weaken the determinism guarantee by removing the time-bomb without a substitute.
**Regression test:** A test that forces `masterDeterminizations` < budget and verifies identical decisions regardless of per-call timing (e.g. patch the Stopwatch, or run two instances with randomized workloads in between).
**Verification:** not run (blocked on final spec).
**Risk of Fix:** changing Master latency/robustness.

### BUG-03 — RULES.md absent (authoritative spec missing)
**Severity:** Medium (documentation/spec gap)
**Affected Package:** repo-level
**Problem:** The audit task and `simulations/test/strength_regression_test.dart` both cite an authoritative RULES.md (230L) for the game rules and for §10 (2026-11-19) AI-strength targets. Neither the rules nor the targets can be verified against the spec because the file is not present.
**Reproduction:** `find . -name 'RULES.md'` → no matches.
**Expected:** RULES.md present in repo.
**Actual:** absent.
**Fix:** Re-paste RULES.md.
**Verification:** once present, re-diff implemented rules vs the spec (Phase C audit).
**Verification needed:** rules check (blocked).

## Potential risks (NOT confirmed defects — no evidence that occurs in-game)

### RISK-01 — Rng modulo bias
`Rng.nextInt(n)` computes `nextUint32() % n`. `nextUint32` is masked to 31 bits (range [0, 2^31)). For typical n (e.g. n=2..200), modulo bias is negligible (< 1 in 10^9 per call) but nonzero. Existing tests pass; no functional bias in this application.

### RISK-02 — GameConfig has no validation
`GameConfig(matchTarget: 0, tilesPerHand: 0)`, negative values, or `firstRoundStarter: 3` are silently accepted (no `assert`/validation). In a fixed seed these produce deterministic-but-invalid games (e.g. 0 tiles per hand => empty hands immediately). No test exercises this.

### RISK-03 — mutable globals in AI
`evaluator.activeWinBonus` (default 100.0) and `policy.activeRolloutWeights` (defaults to `PolicyWeights.rollout`) are module-level mutable variables. Any in-process consumer can mutate them at any time — e.g. a tuning pass silently returns AI behavior inconsistent across contexts.

### RISK-04 — engine_test has no scenario for "invalid draw-end selection"
Phase C lists 20 scenarios; the suite covers 19 (all but "invalid draw-end selection", which is not exercised) — the scenario is implicit in legal-action validation tests, but an explicit test (engine rejects `ChooseDrawEnd` when direction is already chosen) is missing.

### RISK-05 — domino_api lacks tests of its own
101 engine-level scenarios are covered only via engine tests and the strength regression. A `test/` directory does not exist in domino_api at all.

## Confirmed defects from THIS audit — zero
No engine/API/AI/simulations defect was confirmed during the audit pass. The 26 (engine) + 13 (AI) + 4 (simulations) baseline tests all passed. The 4 in-scope suite files match the manifest byte-for-byte.

## What this report does NOT do
- Does not claim RULES.md or app/ contents — this **is** an audit of what exists.
- Does not apply any fixes — none were needed for confirmed defects. Remediation log section in REMEDIATION_LOG.md states explicitly.
