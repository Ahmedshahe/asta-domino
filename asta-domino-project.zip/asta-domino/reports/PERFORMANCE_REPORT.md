# PERFORMANCE REPORT — Asta Domino

**Date:** 2026-11-21 (Cairo). **Hardware:** sandbox Dart SDK 3.14.1, linux_x64.
**Method:** dart run micro-benchmarks against real code paths (see REMEDIATION_LOG.md / methodology in REPOSITORY_INVENTORY.md).

## Engine transition time

Measured via in-process `apply()` on a 2000-ply greedy simulation cap (round ended at ~41 plies, average 0.227 ms per `apply`, includes legal-action validation + event construction). One full round (~60-80 plies on average) = roughly 14–18 ms of engine state transitions, **before** AI decision latency.

| Metric | Value |
|---|---|
| Per-action apply() (avg) | ~0.23 ms |
| Per-round engine cost (typical ~60 plies) | ~14 ms |
| Analysis-sensitive step (legalTableActions) | trivial; called once per action in engine |

No hot spots observed in pure table rules. No optimization is justified without a reproducible profile — none was collected.

## AI decision latency (Master level, vs Random)

Measured in-process — 411 decisions, 30 rounds, mid-game.

| Metric | Value |
|---|---|
| p50 | ~0 ms (single-action/final-play rounds) |
| p95 | ~77 ms |
| p99-ish max | ~312 ms (the explicit `masterTimeBudgetMs: 300` is the upper bound of the same loop) |
| Mean over sampled decisions | ~17.96 ms |
| Mean across 1000-round regression benchmark | 21.1 ms |

Master is 2–3 orders of magnitude below anything the UI target (60fps for a Flutter game; AI alone ≈ 20ms at p50) cannot tolerate without threading — but with one AI decision every N plies it is acceptable. Use a worker/isolate if the UI freezes on longer play.

## Monte Carlo throughput (sample + one paired rollout)

~**8,500 sampled worlds/sec** (one `sampleWorldWithBelief` + one `evaluateActionInWorld` per world, in one process). For Master's 150-world × 2-action × 2-rollout default, a single decision ≈ 150 × 2 × 2 rollouts × (up to 10 ms/rollout) = ~150ms expected — matches observed 20ms mean for most decisions (single-action fast paths dominate).

## Memory

Not measured (no read of `--track-heap`/`--track-heapsnapshot` in this run; would need explicit heap dumps). **No memory leaks detected from static inspection.** The AI/coach both allocate per-world; the master loop frees each sampled `TableState` on the same cycle (no accumulation) — the analysis code does not accumulate per-world state across decisions.

## UI frame performance / startup

Not measurable (app absent).

## Opportunities (NOT acted on — no evidence of meaningful pain)

1. `buildBelief` in domino_ai builds `View.unseenTiles` every call (O(28) + set ops) — cheap.
2. `OpponentModel.canPlayProbability` is never exercised in production code (only test); it is also not in the hot path.
3. Determinization loop uses Stopwatch per iteration — cheap.
4. Recycling `Rng` instances per decision — no.

## Verdict
Performance is **acceptable for an AI-playable game** with Master ≈ 20ms avg decision on rules-of-thumb, with tail latency up to the 300ms explicit budget. No code change is justified without an actual performance regression elsewhere in the app.
