# REMEDIATION LOG — Asta Domino

**Date:** 2026-11-21 (Cairo).
**Method:** none of the confirmed defects in BUG_REPORT.md were repaired this session — this was an audit, not a remediation pass. No code was modified. This log records the absence of remediation and why.

## Changes implemented

None.

## Changes deliberately NOT made

- The `stopwatch` determinism in Master AI (BUG-02) — the fix is non-trivial (design of the time-budget protocol is a product decision: fixed worlds vs soft cap) and any change risks Master accuracy and the strength-regression results. Per the task instructions ("Do not silently change game mechanics", "If a fix requires a missing specification, stop and request that specification"), this was left to the spec owner.
- The missing coach files (BUG-01) — not fabricated; the transport rules forbid substituting payload content with reconstruction.
- `GameConfig` validation (RISK-02) — would be a new enforcement point; needs the authoritative spec.
- `Rng` modulo bias (RISK-01) — negligible; would change every seeded simulation output if changed (breaks regression fixtures).
- Mutable globals (RISK-03) — signature changes would break callers; only safe as a future refactor.

## Verification

Existing baseline: engine 26/26 ✓, ai 13/13 ✓, simulations 4/4 ✓ (all recorded in TEST_RESULTS.md). No changes were applied after baseline; baseline remains valid as of today.

## Environment/report infrastructure changes

- `/home/user/domino_master/SETUP_REPORT.md` — transport + setup report (this audit's transport phase).
- `/home/user/domino_master/reports/*.md` — this audit's deliverables.
- `/home/user/dart-sdk/` — Dart SDK 3.14.1 installed this session (was deleted before the audit; re-downloaded).
- `/home/user/tmp_bench/` — scratch benchmark package (kept outside the repo).

## Reproducibility notes

All commands used in this audit are documented in TEST_RESULTS.md. No tests were disabled, removed, or re-ordered. No public API signatures were changed.
