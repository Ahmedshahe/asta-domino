# REPOSITORY INVENTORY — Asta Domino (أسطى الدومينو)

**Environment:** `/home/user/domino_master/` (Linux, Dart SDK 3.14.1 stable on Ubuntu, bash, timeout, unzip). Cairo local date 2026-11-21.
**Transport:** repo arrived as pasted payload (no archive, no app store, no git remote). Full `.zip` never existed in this environment.

## Complete directory tree (actual)

```
/home/user/domino_master/
├── SETUP_REPORT.md                       (transport report written by audit)
└── packages/
    ├── domino_api/                       (9 files — COMPLETE)
    │   ├── pubspec.yaml
    │   ├── lib/domino_api.dart
    │   └── lib/src/{tile,actions,config,events,player_view,rng,table}.dart
    ├── domino_engine/                    (3 files — COMPLETE)
    │   ├── pubspec.yaml
    │   ├── lib/domino_engine.dart
    │   └── test/engine_test.dart
    ├── domino_ai/                        (8 files — COMPLETE)
    │   ├── pubspec.yaml
    │   ├── lib/domino_ai.dart
    │   ├── lib/src/{ai,belief,evaluator,policy,sampler}.dart
    │   └── test/ai_test.dart
    ├── domino_coach/                     (2–11 files — INCOMPLETE)
    │   ├── lib/domino_coach.dart
    │   └── lib/src/analyzer.dart
    └── simulations/                      (3 files — COMPLETE)
        ├── pubspec.yaml
        ├── lib/arena.dart
        └── test/strength_regression_test.dart
```

**Root RULES.md (230L) and README.md (179L) — ABSENT.** app/ — ABSENT.

## Expected structure vs actual

| Expected | Actual |
|---|---|
| packages/domino_api (COMPLETE) | ✅ present, byte-verified |
| packages/domino_engine (COMPLETE) | ✅ present, byte-verified |
| packages/domino_ai (COMPLETE) | ✅ present, byte-verified |
| packages/domino_coach (per manifest 11 files) | ⚠️ partial: 2/11 present |
| packages/simulations (COMPLETE) | ✅ present, byte-verified |
| app/ (Flutter) | ❌ absent |
| RULES.md (spec) | ❌ absent |
| README.md (docs) | ❌ absent |

## Missing-file report (9 domino_coach + 2 spec/docs)

**domino_coach (missing, awaiting payload re-paste):**
- `lib/src/classifier.dart` (165L) — mistake classification
- `lib/src/coach_engine.dart` (50L) — coach orchestration
- `lib/src/decisions.dart` (37L) — DecisionPoint type (**imported by the verified analyzer.dart**)
- `lib/src/exercises.dart` (240L) — practice-exercise generation
- `lib/src/memory.dart` (190L) — aggregated mistake memory
- `lib/src/reports.dart` (103L) — report rendering
- `lib/src/templates_ar.dart` (93L) — Egyptian-Arabic explanation templates
- `pubspec.yaml` (21L)
- `test/coach_test.dart` (265L)

The verified `domino_coach/lib/domino_coach.dart` exports all of the above (except `analyzer.dart`) — the package **cannot compile** as it stands (import resolution failure). Verified evidence: the file imports `decisions.dart`; neither that file nor any of the other seven can be found in the workspace.

**Spec/docs:** RULES.md (230L, manifest sha256 a331ed1…), README.md (179L, sha256 3079546…) — both absent from the payload.

**app/** — expected per the "Expected architecture" list; entire directory absent.

## Unexpected-file report

No files outside the expected tree except `SETUP_REPORT.md` (written by this audit; root-level). No `.zip`, `.apk`, `.aab`, build artifacts, or `.env` files exist. `.git` does NOT exist — the repo is not a git checkout (see §7).

## Dependency map

| Package | Deps (runtime) | Deps (dev) | Depends-on |
|---|---|---|---|
| domino_api | — | test ^1.25.0 | — |
| domino_engine | domino_api | test ^1.25.0 | api |
| domino_ai | domino_api | test ^1.25.0 | api |
| domino_coach | (unverifiable — pubspec missing) | (unverifiable) | api + ai (confirmed by source imports) |
| simulations | domino_api + domino_engine + domino_ai | test ^1.25.0 | api, engine, ai |

## Package dependency graph

```
            domino_api                    (root: zero deps)
               ^     ^
               |     |
        domino_engine  domino_ai          (engine: api only; ai: api only)
               |     |
        simulations -----------------+
               |                       |
        (uses engine + ai at runtime — the ONE legal bridge)
               |
        domino_coach  (NOT analyzable — deps unverifiable)
```

Privacy invariant being enforced structurally: **domino_ai and domino_coach cannot import domino_engine** (no dependency, no test hook, no import in source). Verified by `grep -rn domino_engine packages/domino_ai packages/domino_coach` → only `domino_ai/test/ai_test.dart`'s structural-fairness test reading `pubspec.yaml`'s text; `domino_coach.dart`'s export list is unverifiable.

## Test inventory (actual, all currently present)

| Package | Test files | Cases | Status |
|---|---|---|---|
| domino_api | — (none; `lib/` only — see note below) | — | — |
| domino_engine | `test/engine_test.dart` | 26 | ✅ 26/26 PASS |
| domino_ai | `test/ai_test.dart` | 13 | ✅ 13/13 PASS |
| domino_coach | `test/` (ABSENT — no tests) | — | — |
| simulations | `test/strength_regression_test.dart` | 4 | ✅ 4/4 PASS (~402s total) |

> **Note:** domino_api has **no tests of its own**. All 101 expectation-anchored scenarios in Phase C are covered only via `domino_engine/test/engine_test.dart` and `simulations/test/strength_regression_test.dart`.

## Git integrity report

| Check | Result |
|---|---|
| `.git` present | ❌ no — not a git repository |
| Branch/history | N/A — no `.git`, no log |
| Working-tree status | N/A |
| Remotes | none (none exist) |
| Expected vs actual | Repo is not a git checkout; treat the pasted payload as the only transport |

**No git integrity data exists.** No CHANGELOG/git tags to audit. Verification state = "files on disk verified byte-for-byte vs the 36-line manifest" (line count + sha256 prefix).
