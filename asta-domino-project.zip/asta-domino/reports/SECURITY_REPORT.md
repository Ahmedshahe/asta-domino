# SECURITY REPORT — Asta Domino

**Scope:** packages/domino_api, domino_engine, domino_ai, domino_coach, simulations. The Flutter app is absent.

## 1. Hidden-information leakage (privacy boundary)

| Check | Status | Detail |
|---|---|---|
| domino_ai cannot import domino_engine | ✅ | pubspec has only `domino_api`; `grep -rn domino_engine lib/` → 0 matches in lib |
| domino_ai has no dart:io / no network usage | ✅ | `grep -rn 'dart:io\|dart:html\|HttpClient\|Socket' lib/` → 0 matches; ai_test enforces this |
| domino_coach imports only api+ai (engine never) | ✅ (structural) | `grep -rn domino_engine lib/` → 0 matches (9 of 11 source files are missing, but absence is the expected state) |
| `PlayerView.unseenTiles` computes known/unseen correctly | ✅ | knownTiles = hand ∪ chain; redacts everything else. Draw-end tiles revealed only when viewer is legally allowed to see them |
| Redaction of `TileDrawnEv` | ✅ | `TileDrawnEv.forViewer` — only the drawing player sees the drawn tile; everyone else sees `null` |
| `PlayerView` does NOT expose opponent hand contents | ✅ | only `opponentHandSize` (count), `history` redacted, `drawLineSize` (count), legalActions |
| AI decision is function of view (+seed) | ✅ | structural fairness tests pass; **caveat** — BUG-02 timing dependency |
| Simulated/benchmark package uses real PlayerView | ✅ | `runMatchup` uses `playerView` from the engine with no bypass |

**Conclusion:** no hidden-information leakage is confirmed. The strongest guarantee is structural: the AI and coach physically cannot import the engine's `MatchState`.

## 2. Unsafe serialization
- No JSON / serialization / network calls in any package for game data. ✅
- `DifficultyManager.toJson/fromJson` — pure Map<String, dynamic> round-trip, no types beyond level.index/consecutiveWins/auto. Not network-serialized. ✅ legitimate local state.

## 3. File access / storage
- No `dart:io` outside test files (the structural fairness test in domino_ai uses `dart:io` to grep source — a test-side tool).
- No filesystem access in runtime code (api/engine/ai/simulations). ✅

## 4. Sensitive information
- No API keys, tokens, or private data in the repo. ✅
- No credentials in pubspec.yaml files (all `publish_to: none`). ✅
- No git repository to audit for embedded secrets (nothing). ✅

## 5. Network access
- None — verified absence of `HttpClient`, `Socket`, `dart:io`, `dart:html` in lib code. ✅
> Note: `Stopwatch` wall-clock appears in the AI (Master decision latency control). This is not a network/security issue; reported as a determinism risk under BUG-02 / RISK-02.

## 6. Dependency vulnerabilities
- No external (third-party) runtime dependencies in any package. No `test` package in runtime source. ✅
- `dev_dependencies: test: ^1.25.0` only — the Dart SDK's official test runner.
- No dynamic dependencies, no local file-lock surfaces. ✅

## 7. Unsafe randomness
- All randomness flows through the seeded `Rng` (xorshift32, explicit state snapshot). No `Random()` constructor, no `DateTime.now`, no `Math.random()` in lib code. ✅
- Rule R7 satisfied for domino_api + domino_engine (verified) and in particular nothing wall-clock in those packages.

## 8. Debug-only configurations / signing
- No Flutter app to audit — N/A.
- `publish_to: none` — no accidental pub.dev publication. ✅

## 9. Android permissions / release signing
- No Android configuration present. N/A — explicitly noted as missing (see FINAL_ACCEPTANCE_REPORT).

## 10. Offline operation
✅ Verified: game logic and AI work fully offline; tests use no external network.

**Overall:** PASS (no security issues confirmed; privacy boundary structurally enforced).
