# TEST RESULTS — Asta Domino (Baseline Execution, 2026-11-21)

**Environment:** Linux (Ubuntu 6.8), Dart SDK 3.14.1 stable (installed this session at `/home/user/dart-sdk/`), local Cairo time.
**Commands:**
```
cd packages/domino_api  && dart analyze
cd packages/domino_engine && dart analyze && dart test
cd packages/domino_ai    && dart analyze && dart test
cd packages/simulations  && dart analyze && dart test
```

## Results

### 1. Static analysis (`dart analyze`)
| Package | Result | Runtime |
|---|---|---|
| domino_api | ✅ **No issues found!** | < 3s |
| domino_engine | ✅ **No issues found!** | < 3s |
| domino_ai | ✅ **No issues found!** | < 3s |
| domino_coach | ⛔ cannot analyze — `pubspec.yaml` absent; source imports `decisions.dart`, `classifier.dart`, etc. which are missing | n/a |

### 2. Unit & regression suites
| Package | Suite | Cases | Result | Time |
|---|---|---|---|---|
| domino_engine | `test/engine_test.dart` | 26 | ✅ 26/26 PASS | ~11.4s |
| domino_ai | `test/ai_test.dart` | 13 | ✅ 13/13 PASS | ~10.3s |
| domino_coach | — | — | ⛔ no tests exist (no test dir) | — |
| simulations | `test/strength_regression_test.dart` | 4 | ✅ 4/4 PASS | ~402.7s total (Master vs Random 1000 rounds: 4:21; Master vs Prof 500 rounds: +2:20; ordering 1500/pair: +0:20; Beginner vs Random 1000 rounds: +0:00) |

### 3. Benchmark detail (all fixed-seed, from the regression suite output)
| Matchup | Result | Time |
|---|---|---|
| Master vs Random (1000 rounds) | A wins **765/1000 (76.5%)** vs 235/1000, 0 draws, avg pts A 19.9, **avg decision A = 21.1 ms** | 261s |
| Master vs Professional (500 rounds) | A wins **332/500 (66.4%)** vs 168/500, 0 draws, avg pts A 13.6, avg decision A = 22.9 ms | ~140s incremental |
| Professional vs Skilled (1500 rounds) | 770 (51.3%) vs 726, 4 draws, avg pts 8.6 | — |
| Skilled vs Casual (1500 rounds) | 809 (53.9%) vs 685, 6 draws, avg pts 7.8 | — |
| Casual vs Beginner (1500 rounds) | 786 (52.4%) vs 703, 11 draws, avg pts 9.8 | — |
| Beginner vs Random (1000 rounds) | 482 (48.2%) vs 508, 10 draws, avg pts 9.3 | — |

All four benchmark assertions passed (Master ≥ 75% ✓, Master > Professional ✓, the strict ordering ✓, Beginner parity 45–55% ✓).

### 4. Edge notes
- The full simulations suite is the only source of the Master-vs-Random benchmark — ~6.7 minutes total runtime. This was NOT re-run after any fix (none were applied).
- No test was skipped, disabled, or deleted during the audit.
- `dart test` for domino_coach and domino_api: **not run — no test files exist, not by design.**

## Limitations of this evidence
- Historical targets ("Master ≥ 75% vs Random", strict ordering, Beginner ≡ Random) are documented in `simulations/test/strength_regression_test.dart` comments and cite **RULES.md §10 (2026-11-19)** — **RULES.md is absent from the payload**, so these targets cannot be verified against the authoritative spec. Verified only by the regression test's own expectations.
- No app (F) or coach package test suite was measured; both are missing.
- Benchmark results are deterministic for the current code revision, but the exact expected values were not stored beyond the printed output.

**Status:** `PASS WITH DOCUMENTED LIMITATIONS`
